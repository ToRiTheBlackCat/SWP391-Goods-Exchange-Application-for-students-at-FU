
import ChatContainer from './ChatContainer';

function Chat(){

  return (
    <div style={{backgroundColor: "#ece5dd", height:'100vh'}}>
      <ChatContainer/>
    </div>
  );
}

export default Chat;